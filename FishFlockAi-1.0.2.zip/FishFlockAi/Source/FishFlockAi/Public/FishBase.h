// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "FishLead.h"
#include "GameFramework/Actor.h"
#include "Components/SphereComponent.h"
#include "Camera/PlayerCameraManager.h"

#include "FishBase.generated.h"

class AFishFlockAiSpawner;

UCLASS()
class FISHFLOCKAI_API AFishBase : public AActor
{
	GENERATED_BODY()
	
protected:
	AFishLead* MyFishLead;
	AFishFlockAiSpawner* MyFishSpawner;
	APlayerCameraManager* CurrentPlayerCameraMgr;

	bool bIsRendered;
	bool bIsTooFar;

	FVector CurrentFlockAILocation;
	float CurrentMovementSpeed;   //�����ƶ��ٶ�
	TSet<AActor*> Neighbourhood;  //������
	FVector SpecificNeighbourLocation;
	FVector SeparationComponent;  
	FVector MoveToComponent;

	const UClass* FishBaseClass;

	// Update tick interval
	FVector VectorCharCameraToFlockAI;
	float VectorSizeCharCameraToFlockAI;
	float TempDotProduct;

public:
	UPROPERTY(VisibleDefaultsOnly, Category = "Fish|Spawner")
		USceneComponent* SceneRoot;

	UPROPERTY(VisibleDefaultsOnly, Category = "Fish|Spawner")
		USphereComponent* CheckSphere;

	UPROPERTY(VisibleDefaultsOnly, Category = "Fish|Spawner")
		USkeletalMeshComponent* FishAIBody;

	//���������ٷ�Χ
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float distBehindSpeedUpRange;

	//����ƶ��ٶ�
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float MaxMovementSpeed;

	//�����ƶ��ٶ�
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float BaseMovementSpeed;

	//����Ȩ��
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float SeparationWeight;

	//�ƶ�Ȩ��
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float MoveToWeight;

	//ת���ٶ�
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float BaseTurnSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float FlySpeed;

	

public:	
	// Sets default values for this actor's properties
	AFishBase();
	bool SetFishAILeader(AFishLead* FishLead);

public:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override; 

public:
	void SetFishSpawner(AFishFlockAiSpawner* spawner);
	void ProcessMoveEvent(const float DeltaTime);
	void ResetComponents();
	void CalcMoveToComponent();
	void CalcMoveSpeed(const float DeltaTime);
	void UpdateTickInterval();
	void RandMove(float DeltaTime);
};
