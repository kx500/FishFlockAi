// Copyright 2021 ShuoDun. All Rights Reserved.

#include "FishBase.h"
#include "FishFlockAiSpawner.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Components/SkeletalMeshComponent.h"

// Sets default values
AFishBase::AFishBase()
{
	FishBaseClass = AFishBase::StaticClass();

 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));

	CheckSphere = CreateDefaultSubobject<USphereComponent>(TEXT("FlockAICheckSphere"));
	CheckSphere->SetupAttachment(SceneRoot);
	CheckSphere->SetSphereRadius(10.0f);
	CheckSphere->SetRelativeScale3D(FVector(1,1,1));

	FishAIBody = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("FishAIBody"));
	FishAIBody->SetupAttachment(SceneRoot);
	FishAIBody->CastShadow = false;
	FishAIBody->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	FishAIBody->SetComponentTickEnabled(false);

	MaxMovementSpeed = 600.f;
	BaseMovementSpeed = 100.f;

	SeparationWeight = 200.f;
	MoveToWeight = 5.f;
	BaseTurnSpeed = 1.f;

	MyFishLead = nullptr;
	distBehindSpeedUpRange = 300.0f;
	bIsTooFar = false;
}

// Called when the game starts or when spawned
void AFishBase::BeginPlay()
{
	Super::BeginPlay();

	CurrentPlayerCameraMgr = UGameplayStatics::GetPlayerCameraManager(this, 0);
}

void AFishBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (MyFishLead != nullptr)
	{
		UpdateTickInterval();

		if (!bIsRendered || MyFishLead->bIsMove)
		{
			ProcessMoveEvent(DeltaTime);
		}
	}
}

void AFishBase::UpdateTickInterval()
{
	VectorCharCameraToFlockAI = CurrentFlockAILocation - CurrentPlayerCameraMgr->GetCameraLocation();
	VectorSizeCharCameraToFlockAI = VectorCharCameraToFlockAI.Size();
	
	bIsTooFar = VectorSizeCharCameraToFlockAI > MyFishSpawner->DetectDistance ? true : false;

	if (bIsTooFar != bIsRendered)
	{
		bIsRendered = bIsTooFar;

		if (bIsRendered == true)
		{
			if (!MyFishLead->bIsMove)
			{
				CheckSphere->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			}
			CheckSphere->SetComponentTickEnabled(false);
			FishAIBody->SetComponentTickEnabled(false);
		}
		else 
		{
			CheckSphere->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
			CheckSphere->SetComponentTickEnabled(true);
			FishAIBody->SetComponentTickEnabled(true);

			TempDotProduct = VectorCharCameraToFlockAI.GetSafeNormal() | FQuatRotationMatrix(CurrentPlayerCameraMgr->GetActorQuat()).GetUnitAxis(EAxis::X);
			if (TempDotProduct >= 0.6f)
			{
				PrimaryActorTick.TickInterval = 0.01f * FMath::Lerp(1.f, 3.f, VectorSizeCharCameraToFlockAI / MyFishSpawner->DetectDistance);
			}
			else {
				PrimaryActorTick.TickInterval = VectorSizeCharCameraToFlockAI < 500 ? 0.03f : 0.05f;
			}
		}
	}
}

void AFishBase::SetFishSpawner(AFishFlockAiSpawner* spawner)
{
	MyFishSpawner = spawner;
}

bool AFishBase::SetFishAILeader(AFishLead* FishLead)
{
	if (MyFishLead == nullptr)
	{
		MyFishLead = FishLead;
		if (MyFishLead)
		{
			return true;
		}
		else {
			return false;
		}
	}

	return true;
}

void AFishBase::ProcessMoveEvent(const float DeltaTime)
{
	ResetComponents();

	// calc separation component
	CheckSphere->GetOverlappingActors(Neighbourhood);
	for (auto & TempNeighbour : Neighbourhood)
	{
		SpecificNeighbourLocation = TempNeighbour->GetActorLocation();  //�õ��ص�����λ��
		if (TempNeighbour->GetClass()->IsChildOf(FishBaseClass))
		{
			if (TempNeighbour != this)
			{
				SeparationComponent += CurrentFlockAILocation - SpecificNeighbourLocation; 
			}
		}
	}

	CalcMoveToComponent();
	CalcMoveSpeed(DeltaTime);

	// ��������
	SetActorRotation(FMath::RInterpTo(GetActorRotation(), (SeparationComponent * SeparationWeight + MoveToComponent * MoveToWeight).ToOrientationRotator(), DeltaTime, BaseTurnSpeed));
	//�õ�actor��������
	FVector DeltaLocation = GetActorForwardVector()* DeltaTime* CurrentMovementSpeed;  //�õ��������ƶ�����

	if (CurrentFlockAILocation.Z > MyFishSpawner->DivingUp)
	{
		DeltaLocation.Z = -BaseTurnSpeed;
	}else if (CurrentFlockAILocation.Z < MyFishSpawner->DivingDown)
	{
		DeltaLocation.Z = BaseTurnSpeed;
	}

	AddActorWorldOffset(DeltaLocation);
}

void AFishBase::ResetComponents()
{
	CurrentFlockAILocation = GetActorLocation();
	SeparationComponent = FVector(0, 0, 0);
	MoveToComponent = FVector(0, 0, 0);
}

void AFishBase::CalcMoveToComponent()
{
	// calc MoveToComponent
	MoveToComponent = (MyFishLead->GetActorLocation() - CurrentFlockAILocation);
	MoveToComponent.GetSafeNormal();
}

void AFishBase::CalcMoveSpeed(const float DeltaTime)
{
	//�ж����캽Ա����
	if (GetDistanceTo(MyFishLead) > distBehindSpeedUpRange)
	{
		CurrentMovementSpeed = CurrentMovementSpeed + DeltaTime * (MaxMovementSpeed - CurrentMovementSpeed);
	}
	else {
		CurrentMovementSpeed = CurrentMovementSpeed + DeltaTime * (BaseMovementSpeed - CurrentMovementSpeed);
	}
}

