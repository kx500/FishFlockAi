// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#if WITH_EDITOR

#include "CoreMinimal.h"
#include "UObject/ConstructorHelpers.h"

class AActor;
class UTexture2D;
class UBillboardComponent;

struct FISHFLOCKAI_API FFishFlockAiIconHelper
{
	/** Ensures a billboard component is created and added to the actor's components. */
	template <typename ActorType>
	static UBillboardComponent* EnsureSpriteComponentCreated(ActorType* Actor, const TCHAR* InIconTextureName)
	{
		return EnsureSpriteComponentCreated_Internal(Actor, ActorType::StaticClass(), InIconTextureName);
	}
	
	template <typename ActorType>
	UE_DEPRECATED(4.27, "void EnsureSpriteComponentCreated(Actor, InIconTextureName, InDisplayName) is deprecated. Use EnsureSpriteComponentCreated(Actor, InIconTextureName) instead.")
	static UBillboardComponent* EnsureSpriteComponentCreated(ActorType* Actor, const TCHAR* InIconTextureName, const FText& InDisplayName)
	{
		return EnsureSpriteComponentCreated_Internal(Actor, ActorType::StaticClass(), InIconTextureName);
	}

private:
	static UBillboardComponent* EnsureSpriteComponentCreated_Internal(AActor* Actor, UClass* InClass, const TCHAR* InIconTextureName);
};

#endif