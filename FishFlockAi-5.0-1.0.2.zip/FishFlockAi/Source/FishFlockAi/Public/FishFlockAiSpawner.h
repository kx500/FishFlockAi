// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "FishBase.h"
#include "Components/SplineComponent.h"
#include "FishFlockAiSpawner.generated.h"

UCLASS()
class FISHFLOCKAI_API AFishFlockAiSpawner : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AFishFlockAiSpawner();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

private:
	FVector SpawnRangeMax;
	FVector SpawnRangeMin;

	FTransform SpawnTrans;

	//�캽ʵ��
	AFishLead* FishLead;

	void SpawnLead();
	void SpawnFish();
	void SpawnFishFlock();

public:
	float SpeedScale;
	float CurrentScale;
	float SpawnMaxRange;
	float SpawnMinRange;

	TSubclassOf<AFishLead> FishLeadClass;

public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
		UBillboardComponent* ActorIcon;
#endif

	UPROPERTY(VisibleDefaultsOnly, Category = "Fish|Spawner")
		USceneComponent* SceneRoot;

	UPROPERTY(VisibleDefaultsOnly, Category = "Fish|Spawner")
		USplineComponent* SplineComp;

	//������
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		int FishAmount;

	//�캽Ա�ٶ�
	UPROPERTY(EditAnywhere, Category = "Fish|Spawner")
		float LeadSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float DetectDistance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float DivingUp;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		float DivingDown;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fish|Spawner")
		TSubclassOf<AFishBase> FishClass;

public:

};
