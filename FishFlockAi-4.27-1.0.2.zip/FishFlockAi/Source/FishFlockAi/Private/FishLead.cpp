// Copyright 2021 ShuoDun. All Rights Reserved.

#include "FishLead.h"

// Sets default values
AFishLead::AFishLead()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
}

// Called when the game starts or when spawned
void AFishLead::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AFishLead::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

