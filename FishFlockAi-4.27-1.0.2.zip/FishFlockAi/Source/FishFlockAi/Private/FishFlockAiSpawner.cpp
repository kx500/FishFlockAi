// Copyright 2021 ShuoDun. All Rights Reserved.

#include "FishFlockAiSpawner.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/ConstructorHelpers.h"

#if WITH_EDITOR
#include "FishFlockAiIconHelper.h"
#endif

// Sets default values
AFishFlockAiSpawner::AFishFlockAiSpawner()
{
#if WITH_EDITOR
	ActorIcon = FFishFlockAiIconHelper::EnsureSpriteComponentCreated(this, TEXT("/FishFlockAi/Icons/FishSprite"));
#endif

 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SceneRoot->SetRelativeLocation(FVector(0.f, 0.f, 0.f));
	SplineComp = CreateDefaultSubobject<USplineComponent>(TEXT("SplineComp"));
	SplineComp->SetupAttachment(SceneRoot);
	SplineComp->SetClosedLoop(true);

	SpawnMaxRange = 200;
	SpawnMinRange = 100;
	DivingUp = 0.f;
	DivingDown = -100.f;
	FishAmount = 10;
	LeadSpeed = 300.0f;
	DetectDistance = 3000;

	FishLeadClass = AFishLead::StaticClass();

	static ConstructorHelpers::FClassFinder<AActor> PlayerBPClass(TEXT("Blueprint'/FishFlockAi/Fish/FishBlue.FishBlue_C'"));
	if (PlayerBPClass.Class != nullptr)
	{
		FishClass = PlayerBPClass.Class;
	}
}

// Called when the game starts or when spawned
void AFishFlockAiSpawner::BeginPlay()
{
	Super::BeginPlay();

	SpawnFishFlock();

	if (SplineComp->GetNumberOfSplinePoints() > 2 && FishLead)
	{
		FishLead->bIsMove = true;
	}
}

// Called every frame
void AFishFlockAiSpawner::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (FishLead)
	{
		if (FishLead->bIsMove)
		{
			SpeedScale = LeadSpeed / SplineComp->GetSplineLength() * DeltaTime;
			FVector LeaderLocation = SplineComp->GetLocationAtDistanceAlongSpline(CurrentScale * SplineComp->GetSplineLength(), ESplineCoordinateSpace::World);
			FishLead->SetActorLocation(LeaderLocation);
			if (CurrentScale > 1.f)
			{
				CurrentScale = 0.0f;
			}
			else {
				CurrentScale += SpeedScale;
			}
		}
	}
}

void AFishFlockAiSpawner::SpawnFishFlock()
{
	if (FishAmount <= 0)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.f, FColor::Red, FString("The number of fish must not be lower than 1"));
		return;
	}

	SpawnLead();

	SpawnRangeMax.X = GetActorLocation().X + FishAmount * 10;
	SpawnRangeMax.Y = GetActorLocation().Y + FishAmount * 10;
	SpawnRangeMax.Z = GetActorLocation().Z + DivingUp;

	SpawnRangeMin.X = GetActorLocation().X + 0;
	SpawnRangeMin.Y = GetActorLocation().Y + 0;
	SpawnRangeMin.Z = GetActorLocation().Z + DivingDown;

	for (int i = 0; i < FishAmount; i++)
	{
		SpawnFish();
	}
}

void AFishFlockAiSpawner::SpawnLead()
{
	SpawnTrans = FTransform(GetActorLocation());

	FishLead = Cast<AFishLead>(UGameplayStatics::BeginDeferredActorSpawnFromClass(this, FishLeadClass, SpawnTrans));
	if (FishLead)
	{
		UGameplayStatics::FinishSpawningActor(FishLead, SpawnTrans);
	}
}

void AFishFlockAiSpawner::SpawnFish()
{
	SpawnTrans = FTransform(FVector(FMath::FRandRange(SpawnRangeMin.X, SpawnRangeMax.X), FMath::FRandRange(SpawnRangeMin.Y, SpawnRangeMax.Y), FMath::FRandRange(SpawnRangeMin.Z, SpawnRangeMax.Z)));

	AFishBase* Fish = Cast<AFishBase>(UGameplayStatics::BeginDeferredActorSpawnFromClass(this, FishClass, SpawnTrans));
	if (Fish)
	{
		Fish->SetFishSpawner(this);
		if (FishLead)
		{
			Fish->SetFishAILeader(FishLead);
		}

		UGameplayStatics::FinishSpawningActor(Fish, SpawnTrans);
	}
}
