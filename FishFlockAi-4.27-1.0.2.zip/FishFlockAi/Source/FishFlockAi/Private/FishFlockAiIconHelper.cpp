// Copyright 2021 ShuoDun. All Rights Reserved.

#include "FishFlockAiIconHelper.h"

#if WITH_EDITOR

#include "Components/BillboardComponent.h"
#include "Engine/Texture2D.h"
#include "Modules/ModuleManager.h"


UBillboardComponent* FFishFlockAiIconHelper::EnsureSpriteComponentCreated_Internal(AActor* Actor, UClass* InClass, const TCHAR* InIconTextureName)
{
	UBillboardComponent* ActorIcon = nullptr;
	
	ActorIcon = Actor->FindComponentByClass<UBillboardComponent>();
	if (ActorIcon == nullptr)
	{
		ActorIcon = Actor->CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("Sprite"), true);
	}
	if (ActorIcon != nullptr)
	{
		ConstructorHelpers::FObjectFinderOptional<UTexture2D> Texture(InIconTextureName);

		ActorIcon->Sprite = Texture.Get();
		ActorIcon->bHiddenInGame = true;
		ActorIcon->SpriteInfo.Category = TEXT("FishFlockAi");
		ActorIcon->SpriteInfo.DisplayName = NSLOCTEXT("SpriteCategory", "FishFlockAi", "FishFlockAi");
		ActorIcon->SetupAttachment(Actor->GetRootComponent());
	}

	return ActorIcon;
}

#endif